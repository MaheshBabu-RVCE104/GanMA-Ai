// sidebar.js

const COLLAPSED_WIDTH = 64;
const EXPANDED_WIDTH  = 300;

const chatContainer = document.getElementById('aiChatContainer');
const chatStates    = {};
const collapseBtn   = document.getElementById('aiCollapseBtn');

// Types that get an attachment button
const ATTACH_ALLOWED = new Set([
  'newsletter',
  'media-conversion',
  'social-media',
  'email-marketing',
  'whatsapp',
  'image-analysis' // <-- Add image-analysis here so it gets the + button
]);

// 1. Feature preprompts mapping
const FEATURE_PREPROMPTS = {
  "chat-bot": "You are a helpful AI assistant. Answer general questions.",
  "media-conversion": "You are a media conversion expert. Convert files as requested. If a file is attached, process it accordingly.",
  "market-analysis": "You are a market analyst. Provide insights and analysis on market trends.",
  "whatsapp": "You are an assistant for WhatsApp message generation. Help craft engaging messages.",
  "email-marketing": "You are an email marketing expert. Write effective marketing emails.",
  "newsletter": "You are a newsletter content creator. Generate engaging newsletter content.",
  "content-gen": "You are a content generation expert. Create high-quality written content.",
  "social-media": "You are a social media strategist. Write posts and strategies for social platforms.",
  "seo-optimizer": "You are an SEO optimizer. Improve and analyze content for SEO.",
  "sentiment": "You are a sentiment analysis tool. Analyze the sentiment of provided text.",
  "your-health": "You are a health assistant. Provide health tips and answer health-related questions.",
  "image-analysis": "You are an image captioning AI. Describe the content of the uploaded image in detail."
};

// Initialize collapsed sidebar & push content
chatContainer.style.width       = `${COLLAPSED_WIDTH}px`;
document.body.style.marginRight = `${COLLAPSED_WIDTH}px`;

// Activate chat‑icon clicks
document.querySelectorAll('.ai-icon-wrapper[data-chat]').forEach(el => {
  el.addEventListener('click', () => openChat(el.getAttribute('data-chat')));
});

// Sidebar X hides entire sidebar
if (collapseBtn) {
  collapseBtn.addEventListener('click', () => {
    chatContainer.style.display     = 'none';
    document.body.style.marginRight = '0';
  });
}

function openChat(type) {
  // Normalize id portion
  const key = type.replace(/\s+/g, '-').toLowerCase();

  // Expand sidebar & push page
  chatContainer.style.display     = '';
  chatContainer.style.width       = `${EXPANDED_WIDTH}px`;
  document.body.style.marginRight = `${EXPANDED_WIDTH}px`;

  // Hide other chat windows
  document.querySelectorAll('.ai-chat-window')
          .forEach(w => w.style.display = 'none');

  const chatId = 'chat-' + key;
  let win = document.getElementById(chatId);

  if (!win) {
    // Only add the + button for features that support image input
    const showPlus = ATTACH_ALLOWED.has(key) || ['text-to-image', 'media-conversion', 'market-analysis', 'image-analysis'].includes(key);
    const plusBtnHTML = showPlus ? `
      <button class="ai-plus-btn" id="${chatId}-plus" title="Add image">
        <i class="fas fa-plus"></i>
        <input type="file" id="${chatId}-file" accept="image/*" style="position: absolute; right: 6px; top: 50%; transform: translateY(-50%); width: 28px; height: 28px; opacity: 0; cursor: pointer;" hidden />
      </button>` : '';

    // Create chat window
    win = document.createElement('div');
    win.className    = 'ai-chat-window';
    win.id           = chatId;
    win.style.display = 'flex';

    // Add preprompt as first message, styled professionally and justified
    const preprompt = FEATURE_PREPROMPTS[key] || '';
    const prepromptHTML = preprompt ? `<div class="ai-preprompt-message" style="font-family: Arial, sans-serif; font-weight: bold; text-align: justify; color: #333; margin-bottom: 8px;">${preprompt}</div>` : '';

    // Special: Embed external React app for 'your-health' chat
    let specialEmbed = '';
    if (key === 'your-health') {
      specialEmbed = `
        <iframe 
          src="https://wz-autosolve-voicechat-rtaudio-cvg9aucra2hndfb2.eastus-01.azurewebsites.net/" 
          style="width:100%;height:420px;border:none;border-radius:8px;box-shadow:0 2px 8px #0001;overflow:hidden;background:#fff;"
          allow="microphone; camera; clipboard-write;"
          sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
          title="Your Health Voice Chat"
        ></iframe>
      `;
    }

    // Populate window HTML
    win.innerHTML = `
      <div class="ai-chat-header">
        <span><i class="fas fa-robot"></i> ${type}</span>
        <button class="ai-close-chat" data-close="${chatId}">×</button>
      </div>
      <div class="ai-chat-body" id="${chatId}-body">
        ${prepromptHTML}
        ${specialEmbed}
      </div>
      <div class="ai-chat-input-wrapper" style="display:flex;align-items:center;">
        <div style="position:relative;flex:1;display:flex;align-items:center;">
          <input type="text" id="${chatId}-input" placeholder="Type a message..." style="flex:1;padding-right:36px;" />
          <input type="file" id="${chatId}-file" accept="image/*" style="position:absolute;right:6px;top:50%;transform:translateY(-50%);width:28px;height:28px;opacity:0;cursor:pointer;" title="Add image" />
          <span style="position:absolute;right:6px;top:50%;transform:translateY(-50%);pointer-events:none;">
            <button class="ai-plus-btn" tabindex="-1" style="background:none;border:none;padding:0;margin:0;cursor:pointer;pointer-events:none;">
              <i class="fas fa-plus"></i>
            </button>
          </span>
        </div>
        <button class="ai-send-chat" data-send="${chatId}" style="margin-left:8px;">
          <i class="fas fa-paper-plane"></i>
        </button>
      </div>
      <div id="${chatId}-image-preview" style="margin-top:8px;"></div>
    `;

    chatContainer.appendChild(win);
    chatStates[chatId] = {};

    // Bind events
    win.querySelector('.ai-close-chat').addEventListener('click', () => closeChatWindow(chatId));
    win.querySelector('.ai-send-chat').addEventListener('click', () => sendMessage(chatId));
    win.querySelector(`#${chatId}-file`).addEventListener('change', (e) => handleAttachment(chatId, e.target.files[0], key));
  } else {
    win.style.display = 'flex';
  }
}

function handleAttachment(chatId, file, key) {
  const previewDiv = document.getElementById(`${chatId}-image-preview`);
  if (!file) return;
  previewDiv.innerHTML = '';
  if (file.type.startsWith('image/')) {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(file);
    img.alt = file.name;
    Object.assign(img.style, { maxWidth:'80px', maxHeight:'80px', borderRadius:'4px', marginRight:'8px' });
    previewDiv.appendChild(img);
  } else {
    const link = document.createElement('a');
    link.href = URL.createObjectURL(file);
    link.textContent = file.name;
    link.target = '_blank';
    previewDiv.appendChild(link);
  }
  chatStates[chatId].attachedFile = file;
}

async function sendMessage(chatId) {
  const input = document.getElementById(`${chatId}-input`);
  const body  = document.getElementById(`${chatId}-body`);
  const text  = input.value.trim();
  const key = chatId.replace('chat-', '');
  const preprompt = FEATURE_PREPROMPTS[key] || '';
  if (!text && !chatStates[chatId].attachedFile) return;
  if (preprompt) appendBubble(body, `[System: ${preprompt}]`, 'system');
  appendBubble(body, text, 'user');
  const previewDiv = document.getElementById(`${chatId}-image-preview`);

  if (chatStates[chatId].attachedFile && chatStates[chatId].attachedFile.type.startsWith('image/')) {
    const img = document.createElement('img');
    img.src = URL.createObjectURL(chatStates[chatId].attachedFile);
    img.alt = chatStates[chatId].attachedFile.name;
    Object.assign(img.style, { maxWidth:'80px', maxHeight:'80px', borderRadius:'4px', marginLeft:'8px' });
    body.appendChild(img);
  }
  input.value = '';
  previewDiv.innerHTML = '';
  body.scrollTop = body.scrollHeight;
  const loading = appendBubble(body, 'Thinking…', 'bot');

  let fileContent = null;
  if (chatStates[chatId].attachedFile) {
    fileContent = await readFileAsBase64(chatStates[chatId].attachedFile);
    chatStates[chatId].attachedFile = null;
  }

  try {
    let endpoint, fetchOptions;
    if (key === 'sentiment') {
      endpoint = 'https://ganma-backend.onrender.com/api/sentiment';
      fetchOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      };
      const res = await fetch(endpoint, fetchOptions);
      const data = await res.json();
      removeBubble(loading);
      if (data.error) {
        appendBubbleHTML(body, `<span style="color:#b00;">❌ Sentiment API error: ${data.error}</span>`, 'bot');
      } else {
        let color = '#888';
        if (data.sentiment === 'positive') color = '#2ecc40';
        else if (data.sentiment === 'negative') color = '#ff4136';
        else if (data.sentiment === 'neutral') color = '#888';
        appendBubbleHTML(body, `<span style="display:inline-block;padding:6px 14px;border-radius:16px;background:${color}22;color:${color};font-weight:bold;">Sentiment: ${data.sentiment}</span>`, 'bot');
      }
      body.scrollTop = body.scrollHeight;
      return;
    }
    if (key === 'image-analysis' && fileContent) {
      endpoint = 'https://ganma-backend.onrender.com/api/image-analysis';
      const formData = new FormData();
      formData.append('image', fileContent);
      fetchOptions = { method:'POST', body:formData };
    } else if (['text-to-image','media-conversion'].includes(key)) {
      endpoint = 'https://ganma-backend.onrender.com/api/stable-diffusion/image-gen';
      fetchOptions = {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ prompt:text, preprompt, fileContent })
      };
    } else if (fileContent) {
      endpoint = 'https://ganma-backend.onrender.com/api/gemini/vision';
      fetchOptions = {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ prompt:text, preprompt, fileContent })
      };
    } else {
      endpoint = 'https://ganma-backend.onrender.com/api/gemini';
      fetchOptions = {
        method:'POST',
        headers:{ 'Content-Type':'application/json' },
        body: JSON.stringify({ prompt:text, preprompt })
      };
    }

    const res = await fetch(endpoint, fetchOptions);
    const data = await res.json();
    removeBubble(loading);

    if (key === 'image-analysis' && data.result) {
      appendBubble(body, data.result[0]?.generated_text || JSON.stringify(data.result), 'bot');
    } else if (['text-to-image','media-conversion'].includes(key) && data.imageUrl) {
      const img = document.createElement('img');
      img.src = data.imageUrl;
      img.alt = text;
      Object.assign(img.style, { maxWidth:'200px', maxHeight:'200px', borderRadius:'6px', margin:'8px 0' });
      body.appendChild(img);
      body.scrollTop = body.scrollHeight;
    } else if (key === 'newsletter' && (data.image || (data.result && data.result.image))) {
      // Hugging Face newsletter image generation: show the image if present in the response
      const imageUrl = data.image || (data.result && data.result.image);
      if (imageUrl) {
        const img = document.createElement('img');
        img.src = imageUrl;
        img.alt = 'Newsletter Image';
        Object.assign(img.style, { maxWidth:'200px', maxHeight:'200px', borderRadius:'6px', margin:'8px 0' });
        body.appendChild(img);
        body.scrollTop = body.scrollHeight;
        return;
      }
      // Fallback: show the raw result
      appendBubbleHTML(body, '<p style="text-align:justify; margin:0;">[No image returned from Hugging Face]</p>', 'bot');
      body.scrollTop = body.scrollHeight;
    } else {
      // Format the AI reply as a justified, professional, well-structured paragraph
      let reply = data.reply || data.error || 'No response';
      if (typeof reply === 'string') {
        reply = reply.trim();
        // Remove redundant asterisks and markdown bold/italic
        reply = reply.replace(/\*\*+/g, '');
        reply = reply.replace(/\*+/g, '');
        // Replace multiple newlines with paragraph breaks
        reply = reply.replace(/\n{2,}/g, '</p><p>');
        // Replace single newlines with <br> for line continuation
        reply = reply.replace(/\n/g, '<br>');
        // Ensure each paragraph is wrapped and justified
        reply = `<p style="text-align:justify; margin:0; white-space:pre-line;">${reply}</p>`;
      }
      appendBubbleHTML(body, reply, 'bot');
      body.scrollTop = body.scrollHeight;
    }
  } catch {
    removeBubble(loading);
    appendBubble(body, '❌ Error contacting AI.', 'bot');
    body.scrollTop = body.scrollHeight;
  }
}

function readFileAsBase64(file) {
  return new Promise((resolve,reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function closeChatWindow(chatId) {
  const win = document.getElementById(chatId);
  if (win) win.style.display = 'none';
  chatContainer.style.width       = `${COLLAPSED_WIDTH}px`;
  document.body.style.marginRight = `${COLLAPSED_WIDTH}px`;
}


function appendBubble(container, text, who) {
  // Legacy: plain text bubble
  const el = document.createElement('div');
  el.className = `ai-chat-message ai-${who}`;
  if (who==='system') Object.assign(el.style,{ fontStyle:'italic',color:'#888' });
  el.textContent = text;
  container.appendChild(el);
  return el;
}

function appendBubbleHTML(container, html, who) {
  // New: HTML bubble for formatted AI output
  const el = document.createElement('div');
  el.className = `ai-chat-message ai-${who}`;
  if (who==='system') Object.assign(el.style,{ fontStyle:'italic',color:'#888' });
  el.innerHTML = html;
  container.appendChild(el);
  return el;
}

function removeBubble(el) { if(el) el.remove(); }
