window.loginUser = async function (email, password) {
  try {
    const res = await fetch("https://ganma-backend.onrender.com/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (res.ok) {
      alert("Login successful!");
      console.log("Token:", data.token);
      return data.token;
    } else {
      alert("Login failed: " + data.message);
      return null;
    }
  } catch (err) {
    alert("Login error: " + err.message);
    return null;
  }
};

window.registerUser = async function (email, password) {
  try {
    const res = await fetch("https://ganma-backend.onrender.com/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email, password }),
    });

    const data = await res.json();
    if (res.ok) {
      alert("Registration successful!");
      return true;
    } else {
      alert("Registration failed: " + data.message);
      return false;
    }
  } catch (err) {
    alert("Registration error: " + err.message);
    return false;
  }
};
