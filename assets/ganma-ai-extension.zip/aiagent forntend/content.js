(async () => {
  // ✅ Add this BEFORE appending the sidebar
  const faCDN = document.createElement("link");
  faCDN.rel = "stylesheet";
  faCDN.href = "https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css";
  document.head.appendChild(faCDN);

  const cssUrl = chrome.runtime.getURL("sidebar.css");
  const jsUrl = chrome.runtime.getURL("sidebar.js");

  const style = document.createElement("link");
  style.rel = "stylesheet";
  style.href = cssUrl;
  document.head.appendChild(style);

  // Create sidebar wrapper
  const sidebarWrapper = document.createElement("div");
  sidebarWrapper.innerHTML = `
    <div class="ai-sidebar" id="aiSidebar">
      <div class="ai-nav-icons">
        <div class="ai-icon-wrapper" data-chat="Chat-Bot"><i class="fas fa-comments"></i><span class="ai-tooltip">chat-Me</span></div>
        <div class="ai-icon-wrapper" data-chat="Media Conversion"><i class="fas fa-exchange-alt"></i><span class="ai-tooltip">Media Conversion</span></div>
        <div class="ai-icon-wrapper" data-chat="Market Analysis"><i class="fas fa-chart-line"></i><span class="ai-tooltip">Market Analysis</span></div>
        <div class="ai-icon-wrapper" data-chat="WhatsApp"><i class="fab fa-whatsapp"></i><span class="ai-tooltip">WhatsApp</span></div>
        <div class="ai-icon-wrapper" data-chat="Email Marketing"><i class="fas fa-envelope-open-text"></i><span class="ai-tooltip">Email Marketing</span></div>
        <div class="ai-icon-wrapper" data-chat="Newsletter"><i class="fas fa-newspaper"></i><span class="ai-tooltip">Newsletter</span></div>
        <div class="ai-icon-wrapper" data-chat="Content Gen"><i class="fas fa-pen-nib"></i><span class="ai-tooltip">Content Gen</span></div>
        <div class="ai-icon-wrapper" data-chat="Social Media"><i class="fas fa-share-nodes"></i><span class="ai-tooltip">Social Media</span></div>
        <div class="ai-icon-wrapper" data-chat="SEO Optimizer"><i class="fas fa-magnifying-glass-chart"></i><span class="ai-tooltip">SEO Optimizer</span></div>
        <div class="ai-icon-wrapper" data-chat="Sentiment"><i class="fas fa-face-smile"></i><span class="ai-tooltip">Sentiment</span></div>
        <div class="ai-icon-wrapper" data-chat="Your Health"><i class="fas fa-brain"></i><span class="ai-tooltip">Your Health</span></div>
      </div>
      <div id="aiChatContainer"></div>
      <div class="ai-user-section" style="margin-top:auto; padding-bottom:16px;">
        <div class="ai-user-avatar">
          <i class="fas fa-user-circle fa-2x" id="userIcon" style="cursor: pointer; color: #444;"></i>
        </div>
        <button class="ai-close-btn" id="aiCloseBtn" title="Exit">
          <i class="fas fa-door-open"></i>
        </button>
      </div>
    </div>
  `;

  document.body.appendChild(sidebarWrapper);
  document.body.insertAdjacentHTML("beforeend", `
  <div id="loginModal" style="display:none; position:fixed; top:20%; left:50%; transform:translateX(-50%); background:#fff; border-radius:8px; box-shadow:0 0 10px rgba(0,0,0,0.2); padding:20px; z-index:9999; width:300px;">
    <h3 style="margin-bottom:10px;">Login / Signup</h3>
    <input id="loginEmail" type="email" placeholder="Email" style="width:100%;margin-bottom:10px;padding:8px;">
    <input id="loginPassword" type="password" placeholder="Password" style="width:100%;margin-bottom:10px;padding:8px;">
    <button id="loginBtn" style="width:100%;margin-bottom:10px;padding:8px;background:#4caf50;color:white;">Login</button>
    <button id="registerBtn" style="width:100%;padding:8px;background:#2196f3;color:white;">Sign Up</button>
  </div>
`);

  const authScript = document.createElement("script");
  authScript.src = chrome.runtime.getURL("auth.js");

  authScript.onload = () => {
    const waitForAuth = setInterval(() => {
      const loginBtn = document.getElementById("loginBtn");
      const registerBtn = document.getElementById("registerBtn");
      const authIcon = document.querySelector(".ai-user-avatar");

      if (loginBtn && registerBtn && authIcon && typeof loginUser === "function") {
        clearInterval(waitForAuth);
        // Toggle login modal on avatar click
        authIcon.addEventListener("click", () => {
          const modal = document.getElementById("loginModal");
          modal.style.display = modal.style.display === "none" ? "block" : "none";
        });
        loginBtn.addEventListener("click", async () => {
          const email = document.getElementById("loginEmail").value;
          const password = document.getElementById("loginPassword").value;
          await loginUser(email, password);
        });
        registerBtn.addEventListener("click", async () => {
          const email = document.getElementById("loginEmail").value;
          const password = document.getElementById("loginPassword").value;
          await registerUser(email, password);
        });
      }
    }, 300);
  };

  document.body.appendChild(authScript);

  // ✅ Safe close button logic
  sidebarWrapper.querySelector('#aiCloseBtn')?.addEventListener('click', () => {
    document.getElementById('aiSidebar')?.remove();
    document.body.classList.remove('with-sidebar');
  });

  // ✅ Inject sidebar.js dynamically
  const script = document.createElement("script");
  script.src = jsUrl;
  script.defer = true;
  document.body.appendChild(script);
})();
